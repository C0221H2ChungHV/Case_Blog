<?php
class User extends Controller
{
    public function resigterAuthor()
    {
        echo "dang kys";
//        $newAcc = $this->model("AuthorModel")->resigter();
//        $this->view("user");
    }
}
?>
