<?php
class AuthorModel extends DB {
    public function resigter()
    {


    }
}