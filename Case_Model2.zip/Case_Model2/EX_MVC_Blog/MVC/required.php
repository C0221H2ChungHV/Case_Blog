<?php
require_once "Core/App.php";
require_once "Core/Controller.php";
require_once "Core/DB.php";
require_once "Models/PostModel.php";
require_once "Models/Post.php";
require_once "Models/Author.php";
require_once "Models/AuthorModel.php";
$App = new App();
?>
