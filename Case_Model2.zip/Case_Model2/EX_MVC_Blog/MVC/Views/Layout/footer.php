</footer>
<!-- JavaScript files-->
<script src="http://localhost/M2/LS21/EX_MVC_Blog/Public/vendor/jquery/jquery.min.js"></script>
<script src="http://localhost/M2/LS21/EX_MVC_Blog/Public/vendor/popper.js/umd/popper.min.js"></script>
<script src="http://localhost/M2/LS21/EX_MVC_Blog/Public/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="http://localhost/M2/LS21/EX_MVC_Blog/Public/vendor/jquery.cookie/jquery.cookie.js"></script>
<script src="http://localhost/M2/LS21/EX_MVC_Blog/Public/vendor/@fancyapps/fancybox/jquery.fancybox.min.js"></script>
<script src="http://localhost/M2/LS21/EX_MVC_Blog/Public/js/front.js"></script>
</body>
</html>
